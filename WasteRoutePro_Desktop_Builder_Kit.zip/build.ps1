Param(
  [string]$AppUrl = ""
)

Write-Host "=== WasteRoute Pro — Desktop Builder ==="

# Ensure Node is installed
$node = (Get-Command node -ErrorAction SilentlyContinue)
if (-not $node) {
  Write-Error "Node.js not found. Install LTS from https://nodejs.org/en/download and rerun."
  exit 1
}

Push-Location desktop

if ($AppUrl -ne "") {
  Write-Host "Setting APP_URL to $AppUrl"
  $env:APP_URL = $AppUrl
}

if (-not (Test-Path node_modules)) {
  npm install
}

npm run dist

Pop-Location

Write-Host "Build complete. Check desktop\\dist for the installer EXE."
