# WasteRoute Pro — Desktop Builder Kit

This kit creates a **Windows installer (.exe)** for your office desktop app (Electron).

## Quick local build (no coding)

1) Install **Node.js LTS**: https://nodejs.org/en/download
2) Open **PowerShell** in this folder and run:
```powershell
# Option A: Load your hosted web app inside the desktop shell
.uild.ps1 -AppUrl "https://YOUR-FRONTEND-URL"

# Option B: Bundle static files
# Copy your React build (frontend/dist) into desktop/renderer first, then:
.uild.ps1
```
Installer appears under: `desktop\dist\WasteRoutePro-Setup-0.2.0.exe`

## GitHub Actions (build in the cloud)
- Put this folder into your repo and push.
- Add a repo **Secret** called `APP_URL` (optional).
- Run workflow **Build Windows Desktop App** → download the `.exe` in **Artifacts**.

## Notes
- Unsigned builds will show Windows SmartScreen warning on first run (normal for internal testing).
- Later you can add code signing cert to electron-builder for smooth installs.
