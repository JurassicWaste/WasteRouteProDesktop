# WasteRoute Pro — Desktop (Electron)

## Run in DEV (loads your React dev server)
```powershell
# Terminal 1
cd ..\frontend
npm i
npm run dev  # http://localhost:5173

# Terminal 2
cd ..\desktop
npm i
npm run dev
```

## Build a Windows installer (unsigned)
Option A — **Bundle your hosted site** (no copying files):
```powershell
cd ..\desktop
setx APP_URL "https://YOUR-DOMAIN-HERE"
npm i
npm run dist
# Output: dist\WasteRoutePro-Setup-0.2.0.exe
```

Option B — **Bundle your React build**:
```powershell
cd ..\frontend
npm i && npm run build   # creates dist\
# Copy the dist output into desktop\renderer\ (replace existing index.html)
cd ..\desktop
npm i
npm run dist
```

> Note: You can code-sign later; this builds an unsigned installer suitable for internal office testing.
