const { app, BrowserWindow, shell } = require('electron');
const path = require('path');
const isDev = require('electron-is-dev');

function createWindow () {
  const win = new BrowserWindow({
    width: 1500,
    height: 950,
    minWidth: 1200,
    minHeight: 700,
    backgroundColor: '#111827',
    title: 'WasteRoute Pro – Dispatcher',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true
    }
  });

  const devUrl = process.env.VITE_DEV_URL; // e.g. http://localhost:5173
  const appUrl = process.env.APP_URL; // production hosted URL for your dispatcher
  const localIndex = path.join(__dirname, 'renderer', 'index.html');

  if (isDev && devUrl) {
    win.loadURL(devUrl);
    win.webContents.openDevTools({ mode: 'detach' });
  } else if (appUrl) {
    win.loadURL(appUrl);
  } else {
    win.loadFile(localIndex);
  }

  // open external links in default browser
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
});
