const { contextBridge } = require('electron');
contextBridge.exposeInMainWorld('wasteroute', { version: '0.2.0' });